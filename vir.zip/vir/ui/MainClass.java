package com.vir.ui;
import java.util.Scanner;
import com.vir.beans.VehicleInsuranceRegistration;
import com.vir.dao.InsuranceValidityCheckDaoImpl;
import com.vir.dao.InsuranceValidityCheckdao;
import com.vir.service.VehicleInsuranceRegistrationService;
import com.vir.service.VehicleInsuranceRegistrationServiceImpl;

public class MainClass {
	public static void main(String[] args) {
		VehicleInsuranceRegistration vi=new VehicleInsuranceRegistration();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice:" + " " + "1.VehicleInsuranceRegistration" + "  "
				+ "2.InsuranceValidityCheck" + " " + "3.Exit");
		int n = sc.nextInt();
		switch (n) {
		case 1:VehicleInsuranceRegistrationService vs=new VehicleInsuranceRegistrationServiceImpl();
		System.out.println("VehicleInsuranceRegistration");
	    System.out.println("Enter vehicle No");
	    vi.setVehicleNo(sc.nextInt());
	    System.out.println("Enter vehicle type in number(eg:2 or 3)wheelers");
	    vi.setVehicleType(sc.next());
	    System.out.println("Enter insurance period in years");
		vi.setInsurancePeriod(sc.nextInt());
		System.out.println("Enter Aadhar number");
		vi.setAadharNo(sc.nextLong());
		System.out.println("Enter MobileNo");
		vi.setMobileNo(sc.nextLong());
		
		vs.vehicleInsuranceRegistration(vi);
			break;

		case 2:InsuranceValidityCheckdao ivc=new InsuranceValidityCheckDaoImpl(); 
			System.out.println("2.InsuranceValidityCheck");
			System.out.println("Insurance validity period is:"+vi.getInsurancePeriod());
			System.out.print(ivc.insuranceValidityCheck());
			
			
			break;

		case 3:
			System.out.println("3.Exit");

		}

	}
}