package com.vir.service;

import com.vir.beans.VehicleInsuranceRegistration;
import com.vir.dao.VehicleInsuranceRegistrationdao;
import com.vir.dao.VehicleInsuranceRegistrationdaoImpl;

public class VehicleInsuranceRegistrationServiceImpl implements VehicleInsuranceRegistrationService {
	 VehicleInsuranceRegistrationdao vir=new  VehicleInsuranceRegistrationdaoImpl();
	
	public Integer vehicleInsuranceRegistration(VehicleInsuranceRegistration vi) {
		
		return null;
	}

	public void insuranceValidityCheck() {
		
		
	}

	
	
}
