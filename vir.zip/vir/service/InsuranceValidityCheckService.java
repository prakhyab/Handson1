package com.vir.service;

import com.vir.beans.VehicleInsuranceRegistration;

public interface InsuranceValidityCheckService {
	Integer vehicleInsuranceRegistration();
	void insuranceValidityCheck();

}
