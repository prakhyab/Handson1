package com.vir.service;

import com.vir.beans.VehicleInsuranceRegistration;

public class InsuranceValidityCheckServiceImpl implements InsuranceValidityCheckService{
	
	public void insuranceValidityCheck() {


		
	}

	public Integer vehicleInsuranceRegistration() {
		
		return null;
	}

}
