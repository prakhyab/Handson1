package com.vir.service;

import com.vir.beans.VehicleInsuranceRegistration;

public interface VehicleInsuranceRegistrationService {
	Integer vehicleInsuranceRegistration(VehicleInsuranceRegistration vi);
	void insuranceValidityCheck();

}
