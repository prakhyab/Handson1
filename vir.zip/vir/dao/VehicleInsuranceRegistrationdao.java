package com.vir.dao;

public interface VehicleInsuranceRegistrationdao {

	void vehicleInsuranceRegistration();
	String insuranceValidityCheck();

}
