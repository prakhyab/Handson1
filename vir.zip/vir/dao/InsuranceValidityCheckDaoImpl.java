package com.vir.dao;

import java.time.LocalDateTime;

import com.vir.beans.VehicleInsuranceRegistration;

public class InsuranceValidityCheckDaoImpl implements  InsuranceValidityCheckdao {
	
		
public void vehicleInsuranceRegistration() {
	
		
	
}

public String insuranceValidityCheck() {
	LocalDateTime date = LocalDateTime.parse(VehicleInsuranceRegistration.getDate(), dtf);
    date= date.plusYears(VehicleInsuranceRegistration.getInsurancePeriod());
    String EnddateofInsurance = date.format(dtf);
    System.out.println(EnddateofInsurance);	
		return EnddateofInsurance;
	}

}
