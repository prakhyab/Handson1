package com.vir.dao;

import java.util.HashMap;

import com.vir.beans.VehicleInsuranceRegistration;

public class VehicleInsuranceRegistrationdaoImpl implements VehicleInsuranceRegistrationdao{

	
	VehicleInsuranceRegistration vi=new VehicleInsuranceRegistration();
	HashMap<Integer,String>insuranceEntry=new HashMap<Integer,String>();	
			
	public void vehicleInsuranceRegistration() {
		
		insuranceEntry.put(vi.getVehicleNo(),vi.getVehicleType());	
			
			
		}

	public String  insuranceValidityCheck() {
		return null;
		
		
		
	}
}
