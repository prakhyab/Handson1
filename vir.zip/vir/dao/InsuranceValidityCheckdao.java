package com.vir.dao;

public interface InsuranceValidityCheckdao {
void vehicleInsuranceRegistration();
String insuranceValidityCheck();

}
