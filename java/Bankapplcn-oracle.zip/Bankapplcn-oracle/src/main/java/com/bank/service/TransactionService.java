package com.bank.service;

public interface TransactionService {

}
