package com.bank.dao;

import java.sql.Connection;

import Utility.Utility;

public class TransactionDaoimpl implements TransactionDao{
 Utility util1=new Utility();
Connection con1=util1.getconnection();

public void withdraw() {
	
	
	
}
public void deposit() {
	
	
	
}


public void transfer() {
	
}

public void balance() {
	
	
}
 
	
	}


