package com.bank.beans;

public class CustomerInformation {
	long accountNo,password,pancardNo,aadharNo,mobileNumber,balance ;
	String firstName,lastName,emailId,address;
	long transactionId,fromAccountno,toAccountno,amountTransfered;
	
	
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public long getPassword() {
		return password;
	}
	public void setPassword(long password) {
		this.password = password;
	}
	public long getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(long pancardNo) {
		this.pancardNo = pancardNo;
	}
	public long getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public long getFromAccountno() {
		return fromAccountno;
	}
	public void setFromAccountno(long fromAccountno) {
		this.fromAccountno = fromAccountno;
	}
	public long getToAccountno() {
		return toAccountno;
	}
	public void setToAccountno(long toAccountno) {
		this.toAccountno = toAccountno;
	}
	public long getAmountTransfered() {
		return amountTransfered;
	}
	public void setAmountTransfered(long amountTransfered) {
		this.amountTransfered = amountTransfered;
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


















