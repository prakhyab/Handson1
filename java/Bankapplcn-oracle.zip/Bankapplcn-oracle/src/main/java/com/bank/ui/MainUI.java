package com.bank.ui;

import java.util.Scanner;

import com.bank.beans.CustomerInformation;

public class MainUI {

	public static void main(String[] args) {
	CustomerInformation ci=new CustomerInformation();
	System.out.println("Enter your choice:1.Register/Login 2.Transaction ");	
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	switch(n) 
	{
	  case 1:System.out.println("Register");
	  System.out.println("Enter your Details");
	  ci.setFirstName(sc.next());
	  ci.setLastName(sc.next());
	  ci.setEmailId(sc.next());
	  ci.setPancardNo(sc.nextLong());
	  ci.setAadharNo(sc.nextLong());
	  ci.setAddress(sc.next());
	  ci.setMobile
	  
	  
	  
	  
	  
	     switch(i) {
	        
	     }
	   break;	
	case 2:System.out.println("");
	break;
	
	}

}
}