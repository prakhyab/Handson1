package com.bank.dao;

public interface TransactionDao {
void withdraw();
void deposit();
void transfer();
void balance();
}
