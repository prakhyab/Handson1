
public class Register {

 private String firstname,lastname,address;
 private long password,mobilenumber,aadharnumber;

private void setFirstname(String firstname) {
	this.firstname = firstname;
}
private void setLastname(String lastname) {
	this.lastname = lastname;
}
private void setAddress(String address) {
	this.address = address;
}
private void setPassword(long password) {
	this.password = password;
}
private void setMobilenumber(long mobilenumber) {
	this.mobilenumber = mobilenumber;
}
private void setAadharnumber(long aadharnumber) {
	this.aadharnumber = aadharnumber;
}
private String getFirstname() {
	return firstname;
}
private String getLastname() {
	return lastname;
}
private String getAddress() {
	return address;
}
private long getPassword() {
	return password;
}
private long getMobilenumber() {
	return mobilenumber;
}
private long getAadharnumber() {
	return aadharnumber;
}
}


	
	
	

