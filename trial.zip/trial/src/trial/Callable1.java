package trial;
	import java.util.concurrent.Callable;
	import java.util.concurrent.ExecutorService;
	import java.util.concurrent.Executors;
	import java.util.concurrent.Future;

	public class Callable1 implements Callable {
		 String name;

		public String call()
		{
			//this.name=Thread.currentThread().getName();
			//return name;
			System.out.println(Thread.currentThread().getName());
			return Thread.currentThread().getName();
		}

		public static void main(String[] args) {
			
			ExecutorService ex1=Executors.newSingleThreadExecutor();
			Callable task=new Callable1 ();
			Future<String> obj=ex1.submit(task);
			System.out.println(obj);

		}
}
