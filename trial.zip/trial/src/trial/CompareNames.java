package trial;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class CompareNames {
	public static void main(String[] args) {
	String name;int n;
	for(int i=0;i<n;i++) {
		 CopyOnRightArrayList <String>name=new ArrayList();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the names");
		name=sc.next();
	}
		String name.add(name);
		Iterator iterator=String name.iterator();
		while(iterator.hasNext())
		{
			System.out.print(iterator.next());
		}
		if(iterator.next().equals(name))
		{
			System.out.println("Name exists");
		
		}
		/*else
		{
		System.out.println(name.replace());
		}*/
		
		
}
}	
	



