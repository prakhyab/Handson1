package trial;
import java.util.ArrayList;

import java.util.Scanner;
import java.util.concurrent.CopyOnWriteArrayList;

public class Name1 {
	CopyOnWriteArrayList<String> arraylist=new CopyOnWriteArrayList<String>();
	
	String name;
	Scanner sc=new Scanner(System.in);
	void name()
	{
		
		
		for(int i=0; i<3;i++)
		{
			System.out.println("enter the name");
			String s=sc.nextLine();
			arraylist.add(s);
		}
		System.out.println(arraylist);
		
		
		
		
		for(String p1:arraylist)
		{
			System.out.println("enter the name to compare");
			String newcust=sc.nextLine();
			 if(arraylist.contains(newcust))
			  {
				  System.out.println("already exist please enter other name");
			  }
			 else
			 {
				 arraylist.add(newcust);
				 System.out.println(arraylist);
			 }
		}
  
	}
	
	
	public static void main(String[] args) {
		Name1 name=new Name1();
		name.name();
		
		

	}

}

