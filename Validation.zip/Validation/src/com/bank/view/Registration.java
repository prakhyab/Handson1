package com.bank.view;
import java.util.Scanner;
import com.bank.model.Customer;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
public class Registration {
   static ArrayList<Customer>arraylist=new ArrayList();
        static void setInfo() {
		 Scanner sc=new Scanner(System.in);
		Customer customer=new Customer();
		 System.out.println("Enter name:");
		customer.setCustomername(sc.next());
		System.out.println("Enter address:");
		customer.setAddress(sc.next());
		System.out.println("Enter accountno:");
		customer.setAccountno(sc.nextLong());
		System.out.println("Enter aadharno:");
		customer.setAadharno(sc.nextLong());
		 arraylist.add(customer);
	     }
static void serializeArray() throws IOException {
		FileOutputStream fileoutputstream = new FileOutputStream("d:\\test1.txt");
		ObjectOutputStream objopstream=new ObjectOutputStream(fileoutputstream);
		objopstream.writeObject(arraylist);
		}
static void deserializeArray(){
	FileInputStream fileinputstream;
	try {
		fileinputstream = new FileInputStream("D:\\test1.txt");
		ObjectInputStream objinpstream = new ObjectInputStream(fileinputstream);
		arraylist = (ArrayList<Customer>)objinpstream.readObject();	
		/*for(Customer c1:arraylist) {
			System.out.println("Enter name:"+c1.getCustomername());
			System.out.println("Enter address:"+c1.getAddress());
			System.out.println("Enter account no:"+c1.getAccountno());
			System.out.println("entr aadharno:"+c1.getAadharno());
		}*/
		verification(arraylist);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
static  void verification(ArrayList<Customer> verifyList ) {
	Scanner s=new Scanner(System.in);
	
	long aadhar=0;
	for(Customer c1:verifyList) {
		System.out.println("Enter name:"+c1.getCustomername());
		System.out.println("Enter address:"+c1.getAddress());
		System.out.println("Enter account no:"+c1.getAccountno());
		System.out.println("entr aadharno:"+c1.getAadharno());
		
    	 aadhar=c1.getAadharno();
     }
	
	System.out.println("enter the adhar number u want to search");
	long searchadhar=s.nextLong();
	
	if(searchadhar==aadhar) {
		System.out.println("it already exists");
	}
	else{
		System.out.print(arraylist.add());
	}
}
	public static void main(String[] args) throws IOException {
		
setInfo();
serializeArray();
deserializeArray();
	}

}

